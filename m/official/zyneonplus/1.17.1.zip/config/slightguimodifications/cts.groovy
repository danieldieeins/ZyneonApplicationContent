mainMenu {
    enabled = true
    label {
        position {
            x { it - 2 }
            y { it - 20 }
        }
        text = literal("Zyneon Legacy+")
        align = "right"
        color = 0xFFFFFF
        hoveredColor = 0x55FFFF
        shadow = true
        onClicked = url("https://www.zyneonstudios.com/")
    }
}