var source = "modrinth";
var type = "mods";

function init() {
    const urlParams = new URLSearchParams(window.location.search);
    const source_ = urlParams.get('source');
    const type_ = urlParams.get('type');
    if(source_!=null) {
        source=source_;
    }
    if(type_!=null) {
        type=type_;
    }
    setActive();
}

function setActive() {
    const modrinth = document.querySelector('.modrinth');
    const zyneon = document.querySelector('.zyneon');
    const mods = document.querySelector('.mods');
    const datapacks = document.querySelector('.datapacks');
    const resourcepacks = document.querySelector('.resourcepacks');
    const shaderpacks = document.querySelector('.shaderpacks');
    const modpacks = document.querySelector('.modpacks');
    modrinth.id = "inactive";
    zyneon.id = "inactive";
    mods.id = "inactive";
    datapacks.id = "inactive";
    resourcepacks.id = "inactive";
    shaderpacks.id = "inactive";
    modpacks.id = "inactive";
    document.querySelector('.'+source).id="active";
    document.querySelector('.'+type).id="active";
}

function set(source_,type_) {
    source=source_;
    type=type_;
    setActive();
}

function setType(type_) {
    type=type_;
    setActive();
}

function setSource(source_) {
    source=source_;
    setActive();
}