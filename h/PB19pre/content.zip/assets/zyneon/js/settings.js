const general = document.getElementById("general");
const global = document.getElementById("global");
const profile = document.getElementById("profile");
const generalbutton = document.getElementById("general-settings");
const globalbutton = document.getElementById("global-settings");
const profilebutton = document.getElementById("profile-settings");

function syncGeneralSettings() {
    global.style.display = "none";
    globalbutton.classList.remove("active");
    profile.style.display = "none";
    profilebutton.classList.remove("active");

    general.style.display = "inherit";
    generalbutton.classList.add("active");
    callJavaMethod("button.syncGeneral");
}

function syncGlobalSettings() {
    general.style.display = "none";
    generalbutton.classList.remove("active");
    profile.style.display = "none";
    profilebutton.classList.remove("active");

    global.style.display = "inherit";
    globalbutton.classList.add("active");
    callJavaMethod("button.syncGlobal");
}

function syncProfileSettings() {
    general.style.display = "none";
    generalbutton.classList.remove("active");
    global.style.display = "none";
    globalbutton.classList.remove("active");

    profile.style.display = "inherit";
    profilebutton.classList.add("active");
    callJavaMethod("button.syncProfile");
}