var source = "modrinth";
var type = "mods";
var version;

function init() {
    const urlParams = new URLSearchParams(window.location.search);
    const source_ = urlParams.get('source');
    const type_ = urlParams.get('type');
    version = version.value;
    if(source_!=null) {
        source=source_;
    }
    if(type_!=null) {
        type=type_;
    }
    setActive();
}

function setActive() {
    const modrinth = document.querySelector('.modrinth');
    const zyneon = document.querySelector('.zyneon');
    const fabric = document.querySelector('.fabric');
    const forge = document.querySelector('.forge');
    const datapacks = document.querySelector('.datapacks');
    const maps = document.querySelector('.maps');
    const resourcepacks = document.querySelector('.resourcepacks');
    const shaderpacks = document.querySelector('.shaderpacks');
    const modpacks = document.querySelector('.modpacks');
    modrinth.id = "inactive";
    zyneon.id = "inactive";
    forge.id = "inactive";
    fabric.id = "inactive";
    datapacks.id = "inactive";
    resourcepacks.id = "inactive";
    maps.id = "inactive";
    shaderpacks.id = "inactive";
    modpacks.id = "inactive";
    document.querySelector('.'+source).id="active";
    document.querySelector('.'+type).id="active";
}

function set(source_,type_) {
    source=source_;
    type=type_;
    version = version.value;
    setActive();
}

function setType(type_) {
    type=type_;
    setActive();
}

function setSource(source_) {
    source=source_;
    setActive();
}