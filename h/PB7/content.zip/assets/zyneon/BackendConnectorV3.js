function callJavaMethod(message) {
    console.log("[Launcher-Bridge] "+message);
}

function syncAccount(message) {
    document.body.innerHTML = document.body.innerHTML.replace('%username%', message);
}

function syncButton(message) {
    document.body.innerHTML = document.body.innerHTML.replace('%acc_button%', message);
}

function syncLanguage(path,string) {
    document.body.innerHTML = document.body.innerHTML.replace(path, string);
}

document.addEventListener('contextmenu',function(e){
    e.preventDefault();
});

document.addEventListener('dragstart', function(e){
    e.preventDefault();
});