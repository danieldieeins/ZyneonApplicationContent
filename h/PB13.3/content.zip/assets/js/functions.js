let btn = document.querySelector('#btn');
let pfp = document.querySelector('#pfp');
let sidebar = document.querySelector('.sidebar');

document.addEventListener('contextmenu',function(e){
    e.preventDefault();
});

document.addEventListener('dragstart', function(e){
    e.preventDefault();
});
        
btn.onclick = function () {
    sidebar.classList.toggle('active');
};

pfp.onclick = function () {
    sidebar.classList.toggle('active');
};

function activateSidebar() {
    sidebar.classList.add('active');
}

function deactivateSidebar() {
    sidebar.classList.remove('active');
}

function toggleSidebar() {
    sidebar.classList.toggle('active');
}

function changeFrame(url) {
    if(url=="instances.html") {
        sidebar.classList.remove('active');
        const urlParams = new URLSearchParams(window.location.search);
        var zyneonplus = urlParams.get('zyneonplus');
        if(zyneonplus==null) {
            zyneonplus = "dynamic";
        }
        url = url+"?zyneonplus="+zyneonplus;
    } else if(url=="start/index.html") {
        sidebar.classList.add('active');
    } else if(url=="wiki.html") {
        sidebar.classList.remove('active');
    } else if(url=="settings.html") {
        sidebar.classList.remove('active');
    }
    var iframe = document.getElementById('iframe');
    iframe.src = url;
}

function login(username) {
    document.getElementById("account").textContent = "Logout";
    document.getElementById("username").textContent = username;
    var pfp = document.getElementById("pfp");
    pfp.src = "https://cravatar.eu/helmhead/"+username+"/64"
    pfp.alt = username+"'s minecraft ingame head"
}

function logout() {
    document.getElementById("account").textContent = "Login";
    document.getElementById("username").textContent = "Unknown";
    var pfp = document.getElementById("pfp");
    pfp.src = "assets/images/steve.png";
    pfp.alt = "default profile picture";
}

function turnOnLights() {
    document.getElementById('index-style').href = 'assets/css/light/index.css';
    document.getElementById('style').href = 'assets/css/light/style.css';
}

function turnOffLights() {
    document.getElementById('index-style').href = 'assets/css/index.css';
    document.getElementById('style').href = 'assets/css/style.css';
}

function callJavaMethod(message) {
    console.log("[Launcher-Bridge] "+message);
}

function setInstanceIcon(icon) {
    document.getElementById('instance-icon').src = icon;
}

function setInstanceTitle(title) {
    document.getElementById('instance-name').textContent = title;
}

function setInstanceLogo(logo) {
    document.getElementById('instance-logo').src = logo;
}

function setInstanceDescription(description) {
    document.getElementById('instance-description').textContent = description;
}

function setInstanceID(id) {
    document.getElementById('instance-settings').href = "javascript:callJavaMethod('button.settings."+id+"');";
    document.getElementById('play-command').href = "javascript:callJavaMethod('button.start."+id+"');";
    setInstanceBackground("../assets/images/instances/"+id+".webp");
}

function setInstanceBackground(background) {
    document.getElementById('instance-background').textContent = "body{background-image: url('"+background+"');background-position: center;background-size: cover;}";
}

function syncZynstance() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if(id!=null) {
        setInstanceID(id);
    }
    const title = urlParams.get('title');
    if(title!=null) {
        setInstanceTitle(title);
        if(title=="Latest") {
            document.getElementById('latestbutton').classList.remove("version-latest");
            document.getElementById('latestbutton').classList.add("selected-latest");
        } else if(title=="Latest VR") {
            document.getElementById('vrbutton').classList.remove("version");
            document.getElementById('vrbutton').classList.add("selected-vr");
            document.getElementById('latestbutton').classList.remove("version-latest");
            document.getElementById('latestbutton').classList.add("version-white");
        } else if(title=="1.16.5") {
            document.getElementById('button1165').classList.remove("version");
            document.getElementById('button1165').classList.add("selected");
        } else if(title=="1.17.1") {
            document.getElementById('button1171').classList.remove("version");
            document.getElementById('button1171').classList.add("selected");
        } else if(title=="1.18.2") {
            document.getElementById('button1182').classList.remove("version");
            document.getElementById('button1182').classList.add("selected");
        } else if(title=="1.19.4") {
            document.getElementById('button1194').classList.remove("version");
            document.getElementById('button1194').classList.add("selected");
        } else if(title=="1.20.1") {
            document.getElementById('button1201').classList.remove("version");
            document.getElementById('button1201').classList.add("selected");
        } else if(title=="1.20.2") {
            document.getElementById('button120').classList.remove("version");
            document.getElementById('button120').classList.add("selected");
        }
    }
    const description = urlParams.get('description');
    if(description!=null) {
        setInstanceDescription(description);
    }
}

function syncInstance() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if(id!=null) {
        setInstanceID(id);
    }
    const icon = urlParams.get('icon');
    if(icon!=null) {
        setInstanceIcon(icon);
    }
    const title = urlParams.get('title');
    if(title!=null) {
        setInstanceTitle(title);
    }
    const logo = urlParams.get('logo');
    if(logo!=null) {
        setInstanceLogo(logo);
    }
    const description = urlParams.get('description');
    if(description!=null) {
        setInstanceDescription(description);
    }
}

function syncSettings() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if(id!=null) {
        document.getElementById('back-to-instance').href = "javascript:callJavaMethod('button.showinstance"+id+"');";
    }
    const title = urlParams.get('title');
    if(title!=null) {
        setInstanceTitle(title);
    }
    const icon = urlParams.get('icon');
    if(icon!=null) {
        setInstanceIcon(icon);
    }
}

function syncZyneonPlus() {
    const urlParams = new URLSearchParams(window.location.search);
    var version = urlParams.get('version');
    var title = version;
    if(version!=null) {
        if(version=="dynamic") {
            title = "Latest";
        } else if(version=="vr") {
            title = "Latest VR";
        }
        changeFrame("instances/zyneonplus.html?id=official/zyneonplus/"+version+"&title="+title+"&background=../assets/images/instances/zyneonplus/dynamic.webp&description=The best way to play Minecraft. More FPS, shaders, custom resource features and simple online play.");
    }
}

function checkStart() {
    const urlParams = new URLSearchParams(window.location.search);
    var tab = urlParams.get('tab');
    if(tab!=null) {
        changeFrame(tab);
    }
}

function syncGeneral() {
    const urlParams = new URLSearchParams(window.location.search);
    const tab = urlParams.get('general-tab');
    const theme = urlParams.get('general-theme');
    if(tab!=null) {
        if(tab=="instances") {
            document.querySelector('.tab_instances').id = "selected";
        } else {
            document.querySelector('.tab_start').id = "selected";
        }
    } else {
        document.querySelector('.tab_start').id = "selected";
    }
    if(theme!=null) {
        if(theme=="light") {
            document.querySelector('.theme_light').id = "selected";
        } else {
            document.querySelector('.theme_dark').id = "selected";
        }
    } else {
        document.querySelector('.theme_dark').id = "selected";
    }
}

function syncGlobal() {
    const urlParams = new URLSearchParams(window.location.search);
    if(urlParams.get("memory")!=null) {
        document.querySelector('.global_memoryint').textContent = urlParams.get("memory")+" (MB)";
    }
}

function syncProfile() {
    const urlParams = new URLSearchParams(window.location.search);
    document.querySelector('#bottom2').textContent = urlParams.get("username");
    document.querySelector('#profile_uuid').textContent = urlParams.get("uuid");
    document.querySelector('#profile-image').src = "https://cravatar.eu/helmhead/"+urlParams.get("username")+"/400";
}

function syncSettings() {
    const urlParams = new URLSearchParams(window.location.search);
    const iframe = document.querySelector('.iframe');
    if(urlParams.get("tab")!=null) {
        var url = "settings/"+urlParams.get("tab");
        if(urlParams.get("general-tab")!=null) {
            url = url+"?general-tab="+urlParams.get("general-tab")+"&general-theme=dark"+"&general-language="+"english";
            document.querySelector('.iframe');
        } else if(urlParams.get("memory")!=null) {
            url = url+"?memory="+urlParams.get("memory");
        } else if(urlParams.get("username")!=null) {
            url = url+"?username="+urlParams.get("username")+"&uuid="+urlParams.get("uuid");
        }
        iframe.src = url;
    } else {
        callJavaMethod('sync.settings.general');
    }
}