async function loadAndProcessJson() {
    try {  
      const jsonFilePath = 'http://localhost:1624';
      const response = await fetch(jsonFilePath);
      const jsonData = await response.json();
      jsonData.instances.forEach(instance => {
        var id = instance.id;
        if(!id.includes("official/")) {
          console.log('Minecraft-Version:', instance.minecraft);
          console.log('Name:', instance.name);
          console.log('ID:', instance.id);
          console.log('Version:', instance.version);
          console.log('Modloader:', instance.modloader);
          console.log('------------------------');
          var originalElement = document.getElementById('instance');
          var clonedElement = originalElement.cloneNode(true);
          clonedElement.id = instance.id;
          var aElement = clonedElement.querySelector('a');
          if (aElement) {
              aElement.onclick = function() {
                  changeFrame("instances/view.html?pack="+instance.id+"&id="+instance.id+"&title="+instance.name+"&logo=../assets/images/instances/default-logo.png&icon=../assets/images/instances/default.png&description=Placeholder text");
              };
          }
          var imgElement = clonedElement.querySelector('img');
          if (imgElement) {
              imgElement.src = 'assets/images/instances/default.png'; 
          }
          var spanElement = clonedElement.querySelector('.nav-item-img');
          if (spanElement) {
              spanElement.textContent = instance.name;
          }
          originalElement.parentNode.insertBefore(clonedElement, originalElement);
      }
      });
    } catch (error) {
      console.error('Fehler beim Laden oder Verarbeiten der JSON-Datei:', error);
    }
  }